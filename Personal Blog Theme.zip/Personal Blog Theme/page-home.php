<?php
/*
	Template Name: Home Page
 */

get_header(); 

	
get_footer(); ?>
